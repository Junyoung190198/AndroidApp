package com.myapp.myapplication

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private var smsTextView: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        smsTextView = findViewById(R.id.sms_text_view)

        if (checkSmsAndContactsPermission()) {
            displayTestMessage()
        } else {
            requestSmsAndContactsPermission()
        }
    }

    private fun checkSmsAndContactsPermission(): Boolean {
        val smsPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.READ_SMS
        )
        val contactsPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.READ_CONTACTS
        )
        return smsPermission == PackageManager.PERMISSION_GRANTED &&
                contactsPermission == PackageManager.PERMISSION_GRANTED
    }

    private fun requestSmsAndContactsPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.READ_SMS,
                Manifest.permission.READ_CONTACTS
            ),
            SMS_AND_CONTACTS_PERMISSION_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == SMS_AND_CONTACTS_PERMISSION_CODE) {
            if (grantResults.size == 2 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                grantResults[1] == PackageManager.PERMISSION_GRANTED
            ) {
                displayTestMessage()
            } else {
                Toast.makeText(this, "SMS and Contacts permissions denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun getContactName(phoneNumber: String): String {
        val uri: Uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber))
        val cursor = contentResolver.query(
            uri,
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
            null,
            null,
            null
        )

        return cursor?.use { cursor ->
            if (cursor.moveToFirst()) {
                val columnIndex = cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME)
                if (columnIndex >= 0) {
                    cursor.getString(columnIndex) ?: "Unknown"
                } else {
                    "Unknown"
                }
            } else {
                "Unknown"
            }
        } ?: "Unknown"
    }

    private fun displayTestMessage() {
        val uri = Uri.parse("content://sms/inbox")
        val cursor = contentResolver.query(uri, null, null, null, null)

        cursor?.use { cursor ->
            if (cursor.moveToFirst()) {
                val phoneNumberIndex = cursor.getColumnIndex("address")
                val messageIndex = cursor.getColumnIndex("body")
                val messages = mutableListOf<String>()

                do {
                    val phoneNumber = cursor.getString(phoneNumberIndex)
                    val message = cursor.getString(messageIndex)
                    val contactName = getContactName(phoneNumber)
                    val displayedMessage = "Sender: $contactName\nPhone Number: $phoneNumber\nMessage: $message"
                    messages.add(displayedMessage)
                } while (cursor.moveToNext())

                runOnUiThread {
                    smsTextView?.text = messages.joinToString("\n\n")
                }
            } else {
                runOnUiThread {
                    smsTextView?.text = "No SMS messages found"
                }
            }
        }
        cursor?.close()
    }

    companion object {
        private const val SMS_AND_CONTACTS_PERMISSION_CODE = 100
    }
}
