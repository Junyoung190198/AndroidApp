package com.myapp.myapplication

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsMessage
import android.util.Log

class SmsReceiverService : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == "android.provider.Telephony.SMS_RECEIVED") {
            val bundle = intent.extras
            val pdus = bundle?.get("pdus") as Array<*>
            val messages = arrayOfNulls<SmsMessage>(pdus.size)

            for (i in pdus.indices) {
                messages[i] = SmsMessage.createFromPdu(pdus[i] as ByteArray)
            }

            if (messages.isNotEmpty()) {
                val phoneNumber = messages[0]?.originatingAddress ?: "Unknown"
                val message = messages.joinToString("\n") { it?.messageBody ?: "" }
                Log.d("SmsReceiverService", "Received SMS from $phoneNumber: $message")
            }
        }
    }
}
